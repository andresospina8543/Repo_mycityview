package co.com.mycityview.model.routes;

import java.util.List;

public class Ruta {

	List<Leg> legs;

	public List<Leg> getLegs() {
		return legs;
	}

	public void setLegs(List<Leg> legs) {
		this.legs = legs;
	}
	
}
